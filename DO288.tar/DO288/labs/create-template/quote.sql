
create table quote (id integer primary key, msg varchar(250));

insert into quote values (1, 'Always remember that you are absolutely unique. Just like everyone else.');

insert into quote values (2, 'Do not take life too seriously. You will never get out of it alive.');

insert into quote values (3, 'People who think they know everything are a great annoyance to those of us who do.');

insert into quote values (4, 'Veni, vidi, vici...');

insert into quote values (5, 'It is easier to find men who will volunteer to die, than to find those who are willing to endure pain with patience.');
