#!/bin/bash

oc expose svc/quotesapi
